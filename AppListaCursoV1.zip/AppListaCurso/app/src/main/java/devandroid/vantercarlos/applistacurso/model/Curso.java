package devandroid.vantercarlos.applistacurso.model;

public class Curso {
}
